from flask import Flask, render_template_string
import psutil
from datetime import datetime
import time

app = Flask(__name__)
BIND_PORT = 8080

# 系统信息缓存 2秒刷新一次
sys_cache = {
    "last_time": 0,
    "cpu_total": 0.0,
    "mem_total": 0.0,
    "uptime": "",
    "cpu_model": "",
    "total_memory_gb": 0.0
}
CACHE_SEC = 2

# 进程类型识别
def get_proc_type(proc_name, cmdline):
    name = proc_name.lower() if proc_name else ""
    cmd = " ".join(cmdline).lower() if cmdline else ""
    if "python" in name or "python" in cmd:
        return "Python"
    elif "java" in name or "java" in cmd or "javaw" in name:
        return "Java"
    elif "node" in name or ".js" in cmd:
        return "JavaScript/Node"
    elif ".c" in cmd and ".cpp" not in cmd:
        return "C语言"
    elif ".cpp" in cmd or "g++" in cmd:
        return "C++"
    elif "nginx" in name or "apache" in name or "httpd" in name:
        return "Web服务(HTML)"
    else:
        return "其他进程"

# 格式化进程运行时间
def format_running_time(create_time):
    now = time.time()
    run_sec = int(now - create_time)
    days = run_sec // 86400
    hours = (run_sec % 86400) // 3600
    minutes = (run_sec % 3600) // 60
    seconds = run_sec % 60
    if days > 0:
        return f"{days}天{hours}时{minutes}分{seconds}秒"
    elif hours > 0:
        return f"{hours}时{minutes}分{seconds}秒"
    elif minutes > 0:
        return f"{minutes}分{seconds}秒"
    else:
        return f"{seconds}秒"

# 获取系统硬件信息+资源
def get_system_info():
    now = time.time()
    if now - sys_cache["last_time"] < CACHE_SEC:
        return sys_cache

    # CPU总使用率
    cpu = psutil.cpu_percent(interval=None)
    # 内存信息
    mem = psutil.virtual_memory()
    total_mem_gb = round(mem.total / 1024 / 1024 / 1024, 2)
    mem_per = mem.percent
    # 系统开机时长
    boot = psutil.boot_time()
    run_sec = now - boot
    day = int(run_sec // 86400)
    hour = int((run_sec % 86400) // 3600)
    minute = int((run_sec % 3600) // 60)
    uptime = f"{day}天 {hour}时 {minute}分"

    # 获取CPU型号
    try:
        with open("/proc/cpuinfo", "r", encoding="utf-8") as f:
            for line in f.readlines():
                if line.startswith("model name"):
                    cpu_model = line.split(":")[1].strip()
                    break
    except:
        cpu_model = "未知CPU型号"

    sys_cache.update({
        "cpu_total": cpu,
        "mem_total": mem_per,
        "uptime": uptime,
        "cpu_model": cpu_model,
        "total_memory_gb": total_mem_gb,
        "last_time": now
    })
    return sys_cache

# 获取所有进程并分类
def get_all_proc_group():
    proc_groups = {
        "Python": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0},
        "Java": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0},
        "JavaScript/Node": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0},
        "C语言": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0},
        "C++": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0},
        "Web服务(HTML)": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0},
        "其他进程": {"list": [], "sum_cpu": 0.0, "sum_mem": 0.0}
    }
    for p in psutil.process_iter(["pid", "name", "cmdline", "cpu_percent", "memory_percent", "create_time"]):
        try:
            pid = p.info["pid"]
            p_name = p.info["name"]
            cmd = p.info["cmdline"]
            cpu = round(p.info["cpu_percent"], 2)
            mem = round(p.info["memory_percent"], 2)
            create_ts = p.info["create_time"]
            run_time_str = format_running_time(create_ts)

            proc_type = get_proc_type(p_name, cmd)
            item = {
                "pid": pid,
                "proc_name": p_name,
                "cpu": cpu,
                "mem": mem,
                "run_time": run_time_str
            }
            proc_groups[proc_type]["list"].append(item)
            proc_groups[proc_type]["sum_cpu"] += cpu
            proc_groups[proc_type]["sum_mem"] += mem
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    # 每组按CPU降序排序
    for key in proc_groups:
        proc_groups[key]["list"].sort(key=lambda x: x["cpu"], reverse=True)
        proc_groups[key]["sum_cpu"] = round(proc_groups[key]["sum_cpu"], 2)
        proc_groups[key]["sum_mem"] = round(proc_groups[key]["sum_mem"], 2)
    return proc_groups

# 前端页面模板 全部刷新改为15秒
HTML_TPL = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta http-equiv="refresh" content="15">
    <title>服务器任务管理器</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Microsoft YaHei", Consolas, monospace;
        }
        body {
            background-color: #0f172a;
            color: #e2e8f0;
            padding: 25px 15px;
            min-height: 100vh;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header-card {
            background: linear-gradient(135deg, #1e293b, #334155);
            border-radius: 16px;
            padding: 26px 20px;
            margin-bottom: 30px;
            text-align: center;
            box-shadow: 0 6px 24px rgba(59,130,246,0.12);
        }
        h1 {
            font-size: clamp(1.8rem, 4vw, 2.6rem);
            color: #3b82f6;
            margin-bottom: 16px;
            letter-spacing: 2px;
        }
        .hardware-info {
            font-size: clamp(1rem, 2vw, 1.15rem);
            color: #94a3b8;
            margin-bottom: 10px;
            line-height: 1.6;
        }
        .global-info {
            font-size: clamp(1.05rem, 2vw, 1.25rem);
            color: #94a3b8;
        }
        .group-card {
            background: #1e293b;
            border-radius: 16px;
            padding: 22px 18px;
            margin-bottom: 26px;
            box-shadow: 0 4px 18px rgba(15,23,42,0.35);
        }
        .group-title {
            font-size: clamp(1.3rem, 2.8vw, 1.6rem);
            color: #60a5fa;
            padding-bottom: 12px;
            margin-bottom: 18px;
            border-bottom: 2px solid #334155;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap:8px;
        }
        .group-summary {
            color:#94a3b8;
            font-size:0.95em;
        }
        .table-wrap {
            overflow-x: auto;
        }
        table {
            width: 100%;
            min-width: 720px;
            border-collapse: collapse;
        }
        th, td {
            padding: 14px 12px;
            text-align: center;
            font-size: clamp(1rem, 2vw, 1.15rem);
            border-bottom: 1px solid #334155;
        }
        th {
            background-color: #334155;
            color: #bfdbfe;
        }
        tr:hover {
            background-color: #273449;
        }
        .empty-tip {
            padding: 40px 10px;
            text-align: center;
            color: #64748b;
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-card">
            <h1>🖥️ 服务器全局任务管理器</h1>
            <div class="hardware-info">
                CPU型号：{{sys.cpu_model}} &nbsp;|&nbsp;
                物理总内存：{{sys.total_memory_gb}} GB
            </div>
            <div class="global-info">
                全局CPU总使用率：{{sys.cpu_total}}% &nbsp;|&nbsp;
                全局内存总使用率：{{sys.mem_total}}% &nbsp;|&nbsp;
                服务器运行时长：{{sys.uptime}} &nbsp;|&nbsp;
                页面每15秒自动刷新
            </div>
        </div>

        {% for group_name, group_data in proc_groups.items() %}
        <div class="group-card">
            <div class="group-title">
                <span>{{group_name}} 进程组</span>
                <span class="group-summary">本组总CPU：{{group_data.sum_cpu}}% &nbsp; 本组总内存：{{group_data.sum_mem}}%</span>
            </div>
            <div class="table-wrap">
                {% if group_data.list %}
                <table>
                    <thead>
                        <tr>
                            <th>PID进程号</th>
                            <th>进程名称</th>
                            <th>CPU占用(%)</th>
                            <th>内存占用(%)</th>
                            <th>进程运行时长</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for item in group_data.list %}
                        <tr>
                            <td>{{item.pid}}</td>
                            <td>{{item.proc_name}}</td>
                            <td>{{item.cpu}}</td>
                            <td>{{item.mem}}</td>
                            <td>{{item.run_time}}</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
                {% else %}
                <div class="empty-tip">当前暂无{{group_name}}类型运行进程</div>
                {% endif %}
            </div>
        </div>
        {% endfor %}
    </div>
</body>
</html>
'''

@app.route('/')
def index():
    sys_info = get_system_info()
    proc_group = get_all_proc_group()
    return render_template_string(
        HTML_TPL,
        sys=sys_info,
        proc_groups=proc_group
    )

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=BIND_PORT, threaded=True, debug=False)