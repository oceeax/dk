#!/usr/bin/env python3
# -*- coding:utf-8 -*-
import os,re,shutil,threading,queue,time,platform,string
SKIP={"windows","program files","program files (x86)","programdata","$recycle.bin",
"system volume information","recovery","perflogs","winsxs","appdata",".git",
"node_modules","__pycache__",".cache","proc","sys","dev","run","snap","boot","lost+found"}
def has_cn(s): return re.search(r'[\u4e00-\u9fff]',s)!=None
home=os.path.expanduser("~")
desk=next((p for p in [os.path.join(home,"Desktop"),os.path.join(home,"桌面")] if os.path.isdir(p)),os.getcwd())
base=os.path.join(desk,"w0")
dirs={"pyc":os.path.join(base,"py_中文名"),"pye":os.path.join(base,"py_非中文名"),
"hc":os.path.join(base,"html_中文名"),"he":os.path.join(base,"html_非中文名")}
for d in dirs.values(): os.makedirs(d,exist_ok=True)
log=open(os.path.join(base,"scan.log"),"w",encoding="utf-8")
def roots():
    if platform.system().lower().startswith("win"):
        return [x+":\\" for x in string.ascii_uppercase if os.path.exists(x+":\\")]
    return ["/"]
Q=queue.Queue()
for r in roots(): Q.put(r)
lock=threading.Lock(); stat={"py":0,"html":0}
def cp(src,dst):
    n=os.path.basename(src); t=os.path.join(dst,n)
    if not os.path.exists(t): shutil.copy(src,t); return
    b,e=os.path.splitext(n);i=1
    while True:
        t=os.path.join(dst,f"{b}_{i}{e}")
        if not os.path.exists(t): shutil.copy(src,t);return
        i+=1
def worker():
    while True:
        try: root=Q.get_nowait()
        except: return
        for cur,sub,files in os.walk(root):
            sub[:]=[d for d in sub if d.lower() not in SKIP and not d.startswith(".")]
            for f in files:
                lf=f.lower()
                try:
                    full=os.path.join(cur,f)
                    if lf.endswith(".py"):
                        cp(full,dirs["pyc"] if has_cn(f) else dirs["pye"]); stat["py"]+=1
                        log.write(full+"\n")
                    elif lf.endswith(".html") or lf.endswith(".htm"):
                        cp(full,dirs["hc"] if has_cn(f) else dirs["he"]); stat["html"]+=1
                        log.write(full+"\n")
                except: pass
        Q.task_done()
ts=time.time()
ths=[threading.Thread(target=worker) for _ in range(max(4,os.cpu_count() or 4))]
[t.start() for t in ths]
[t.join() for t in ths]
log.close()
print("完成",stat,"耗时",round(time.time()-ts,2),"秒")
input("回车退出...")
